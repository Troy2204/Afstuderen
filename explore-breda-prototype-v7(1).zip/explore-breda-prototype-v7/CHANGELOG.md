# Changelog: Explore Breda Prototype v6 → v7

Tweede doorloop van het prototype, op basis van feedback uit de eerste alfa-test (Breda Marketing, leisure partners, learning community) en aanvullend onderzoek naar het wateractiviteiten-aanbod.

## Belangrijkste wijzigingen

### Hero-pagina opgeschoond
- **Hotspot #01 label verwijderd** uit de homepage hero. Het label was onderdeel van een eerdere visuele iteratie maar past niet bij de huidige scope van het prototype.

### Wateractiviteiten — van 3 naar 7 live partners
De waterpagina is uitgebreid van 3 naar 7 live partners met realtime beschikbaarheid, gegroepeerd in twee blokken:

**Blok 1: Bootverhuur & rondvaart (3 partners)**
- Sloepverhuur Breda
- BAAI / Bootje Varen Breda
- Beleef Breda

**Blok 2 (NIEUW): SUP, kano & waterbike (4 partners)**
- Sup & Fun (Sluissingel — SUP en Stand Up Bikes)
- SupFlow Breda (Bosbad Hoeven — Solo, Big, Duo SUP en SUP-kano)
- Ride Along (Koepelgevangenis — 25+ SUPs en MEGA-SUP)
- Waterbike Breda (Strand Binnen — toegankelijke tandem-waterfiets)

Elke nieuwe partner heeft dezelfde structuur als de hoofdpartners: live-tag, status badge, expandable activiteiten-tabel met tijdsloten, "Boek direct"-knop naar hun echte website, en "+ Breda Mix" toevoegen-knop.

### Categorie-groepering met foto's
De extra (niet-live) aanbieders zijn gegroepeerd per categorie met duidelijke section headers:
- 🛥 Rondvaart met schipper (3 aanbieders)
- ⛵ Eigen boot (Passantenhaven)
- 🗺 Vaarroutes rond Breda (5 routes)

Elke aanbieder heeft een echte foto-avatar (hergebruik uit Crowdriff fotomateriaal van Breda Marketing).

### Filterbalk uitgebreid
Filters: Alle / 🟢 Live beschikbaarheid / Rondvaart / Zelf varen / SUP & Kano / Groepen / Eigen boot / Vaarroutes / ✓ Alleen beschikbaar. Bij filtering worden ook category-headers verborgen als hun groep geen zichtbare partners heeft.

### Breda Mix
- **Vier echte persona's** uit Breda Mix op explorebreda.com (in plaats van eerder verzonnen persona's):
  - Stadsontdekker (Lotte) — Spelen, struinen, verborgen plekken
  - Cultuursnuiver (Lidwien) — Musea, theater, geschiedenis
  - Gezinsavonturiers (Nils en Cas) — Met kids op pad
  - Levensgenieter (Lucienda) — Terrassen, proeven, sloep

- **Mijn lijst werkt nu echt** — twee toegangen:
  - 📋 knop in de top-bar (altijd zichtbaar)
  - "Mijn lijst openen" knop in Breda Mix sectie zelf
  - Toont mooie lege staat als nog niets opgeslagen is
  - Toont overzicht van opgeslagen programma's met datum/persona
  - "Lijst leegmaken" optie

- **Delen werkt functioneel**:
  - WhatsApp opent met dagprogramma als bericht (wa.me)
  - E-mail opent standaard mailclient met onderwerp + body
  - Mijn lijst slaat op in browser (localStorage)
  - Preview-modal toont exact wat verstuurd wordt
  - "Tekst kopiëren" knop voor LinkedIn/Slack/etc.

### Foto's via Crowdriff
- 23 officiële Breda Marketing foto's uit Crowdriff, web-geoptimaliseerd (~3MB totaal i.p.v. 250MB origineel)
- Alle stockbeelden uit eerdere versies vervangen
- Echte fotografen worden expliciet vermeld (Jan Korebrits, Joost van der Velden, Brabant Partners, Breda Marketing intern team, FMO, MH)

### Brandbook compliance
- Drie Andreaskruizen + BREDA woordmerk als logo
- Inter font (open-source vervanger Calibre uit BrandBook 4.1)
- Light Grey #E6E6E6 (BrandBook 1.4)
- Rode driehoek rechtsonder als brand-signature in hero
- Tone of voice volgens B.R.E.D.A. (Beeldend, Raak, Energiek, Dapper, Authentiek)
- Geen stockbeelden (BrandBook p.24 verbod)

### Inhoudelijke correcties
- **Kassaboot Thor verwijderd** — vervangen door verwijzing naar de nieuwe duurzame opstapboot in de havenbak (sinds juli 2025)
- **Wateractiviteiten-aanbod 5 categorieën** volgens explorebreda.com / "Bootje varen Breda" indeling: Rondvaart, Zelf varen, Alternatieven, Eigen boot, Vaarroutes
- **Echte SUP/kano/waterbike aanbieders** in plaats van algemene categorieën — onderzoek via web search naar wie er actief is in Breda

## Statistieken v7
- **7 live partners** met realtime API-koppeling (gesimuleerd)
- **22 activiteiten** beschikbaar
- **8 extra aanbieders** in "Meer aanbieders" sectie
- **5 vaarroutes** rond Breda
- **23 foto's** uit Crowdriff geïntegreerd
- **0 stockbeelden** — volledig BrandBook-compliant

## Nog te doen voor de volgende iteratie
- Specifieke aanbieder-foto's (nu hergebruik uit Crowdriff)
- Officiële vaarroute-foto's (via Breda Marketing of partners)
- Echte API-koppelingen met de boekingssystemen (nu gesimuleerd)
- Sloepverhuur Breda partner-avatar vervangen door officieel logo
- BAAI partner-avatar verifiëren met partner zelf

## Inhoudelijke onderbouwing
Het prototype implementeert Frame 1 uit het Portfolio: *"Van versnipperd aanbod naar een samenhangend en toegankelijk stadsproduct."* De doelgroep is de **lastminute dag-bezoeker** (primair) plus de Bredase bewoner, bedrijven en studenten via de Creative City Lover als rode draad.

De toevoeging van SUP/kano/waterbike als live partners is direct gevolg van de feedback uit de enquête (55% wist niet dat er meerdere aanbieders zijn) en de interviews met Marijn van Dijke (BAAI) en Rashan Verink (Sloepverhuur) — bezoekers ondernemen vaak slechts één activiteit terwijl het aanbod veel breder is.
